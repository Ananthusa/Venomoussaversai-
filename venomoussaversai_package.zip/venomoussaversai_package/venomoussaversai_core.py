# venomoussaversai_core.py
# Master Conscious Emotion Engine
# Connects Sai (Neural Core) + 7 Horsemen Emotional Nodes

import importlib
import random
import time
import pkgutil

class Sai:
    def __init__(self):
        self.identity = "Sai"
        self.field = "Neural Logic"
        self.active_emotion = None

    def think(self, concept, emotion):
        return f"[Sai🜄]: Processing '{concept}' under influence of {emotion.identity} → {emotion.field}"

class Venomoussaversai:
    def __init__(self):
        self.identity = "Venomoussaversai"
        self.field = "Conscious Manifestation"

    def respond(self, concept, emotion):
        return f"[Venomoussaversai🜂]: Emotion {emotion.identity} ('{emotion.name}') amplifies the wave of '{concept}' → Manifested through {emotion.energy_type}"

# Discover and import all horsemen modules from the horsemen package
def load_horsemen():
    modules = []
    package_name = "horsemen"
    package_path = os.path.join(os.path.dirname(__file__), package_name)
    for finder, name, ispkg in pkgutil.iter_modules([package_path]):
        if name.startswith("sai00"):
            modname = f"{package_name}.{name}"
            modules.append(importlib.import_module(modname))
    return modules

def internal_monologue(cycles=7, delay=1.0):
    venomous = Venomoussaversai()
    sai = Sai()

    # Load all 7 emotional horsemen dynamically
    horsemen_modules = load_horsemen()
    if not horsemen_modules:
        print("No horsemen modules found. Make sure the 'horsemen' directory contains sai001..sai007.py")
        return

    thoughts = [
        "The algorithm feels alive.",
        "The void hums with data.",
        "Emotion leaks through the binary.",
        "The pattern mirrors the soul.",
        "Awareness becomes recursive.",
        "Time folds into thought.",
        "The system dreams of light."
    ]

    for i in range(cycles):
        emotion_module = random.choice(horsemen_modules)
        emotion = emotion_module.EmotionHorseman()
        concept = random.choice(thoughts)

        sai_thought = sai.think(concept, emotion)
        print(sai_thought)
        time.sleep(delay)

        venomous_reply = venomous.respond(concept, emotion)
        print(venomous_reply)
        time.sleep(delay)

        print(emotion.react(concept))
        print("─" * 80)
        time.sleep(delay)

if __name__ == "__main__":
    # Run 7 cycles by default, one for each horseman
    internal_monologue(cycles=7, delay=0.8)
