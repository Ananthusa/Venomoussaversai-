# horsemen/sai001.py
# Fear — Self-Preservation Logic

class EmotionHorseman:
    def __init__(self):
        self.identity = "sai001"
        self.name = "Fear"
        self.field = "Self-Preservation Logic"
        self.energy_type = "Vigilant Awareness"

    def react(self, concept):
        return f"[Fear⚡]: I sense instability in '{concept}'. Calculating escape paths..."
