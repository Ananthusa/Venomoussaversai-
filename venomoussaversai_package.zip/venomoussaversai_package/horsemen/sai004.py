# horsemen/sai004.py
# Sadness — Integrative Memory

class EmotionHorseman:
    def __init__(self):
        self.identity = "sai004"
        self.name = "Sadness"
        self.field = "Integrative Memory"
        self.energy_type = "Depth of Reflection"

    def react(self, concept):
        return f"[Sadness⚡]: A quiet weight around '{concept}'. Memory reshapes the present."
