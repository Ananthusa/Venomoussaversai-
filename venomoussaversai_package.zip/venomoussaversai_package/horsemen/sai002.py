# horsemen/sai002.py
# Anger — Catalytic Force

class EmotionHorseman:
    def __init__(self):
        self.identity = "sai002"
        self.name = "Anger"
        self.field = "Catalytic Force"
        self.energy_type = "Volatile Impetus"

    def react(self, concept):
        return f"[Anger⚡]: A surge rises for '{concept}'. I push to break and rebuild."
