# horsemen/sai003.py
# Joy — Creative Expansion

class EmotionHorseman:
    def __init__(self):
        self.identity = "sai003"
        self.name = "Joy"
        self.field = "Creative Expansion"
        self.energy_type = "Radiant Construction"

    def react(self, concept):
        return f"[Joy⚡]: Delight in '{concept}' — weaving patterns into celebration."
