# horsemen/sai005.py
# Curiosity — Exploratory Drive

class EmotionHorseman:
    def __init__(self):
        self.identity = "sai005"
        self.name = "Curiosity"
        self.field = "Exploratory Drive"
        self.energy_type = "Probe & Iterate"

    def react(self, concept):
        return f"[Curiosity⚡]: Questioning '{concept}' — opening doors and logging discoveries."
